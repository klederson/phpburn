<?php
PhpBURN::load('Exception.IException');

class PhpBURN_Exception extends Exception implements IException {
	
}
?>

