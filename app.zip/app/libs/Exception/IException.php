<?php
interface IException
{
	
}
?>
