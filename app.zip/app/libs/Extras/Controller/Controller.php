<?php
/**
 * This class controls the main functions of controllers and actions calls
 * 
 * @version 0.1
 * @author Klederson Bueno <klederson@klederson.com>
 */


//Calling the Interface
require_once('IController.php');

abstract class Controller implements IController {
	
}
?>