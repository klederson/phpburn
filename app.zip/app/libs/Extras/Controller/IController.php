<?php
interface IController {
	
}
?>